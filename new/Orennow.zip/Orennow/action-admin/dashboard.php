



    <section class="content">
        <div class="container-fluid">
            <div class="block-header">
                <h2>DASHBOARD</h2>
            </div>
            
            <h1 style="color:#5c90b9;">Welcome To Homoeocon 2020 "Magnum Opus"</h1>
            <hr>
            <img src="images/home2.jpg" width="100%">

             <!--Widgets -->
        
 <?php
//include("db.php");

//$result = mysqli_query($db,"select count(1) FROM sliders");
//$row = mysqli_fetch_array($result);

//$total = $row[0];
// echo "Total rows: " . $total;
?>
            
           <!-- <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">
                    <div class="info-box bg-pink hover-expand-effect">
                        <div class="icon">
                            <i class="material-icons">perm_media</i>
                        </div>
                        <div class="content">
                            <div class="text">Total Slider Images</div>
                            <div class="number count-to" data-from="0" data-to="<?php// echo $total; ?>" data-speed="1000" data-fresh-interval="20"></div>
                        </div>
                    </div>
                </div>-->

<?php
//include("db.php");

//$result = mysqli_query($db,"select count(1) FROM events");
//$row = mysqli_fetch_array($result);

//$total = $row[0];
// echo "Total rows: " . $total;
?>
            
            <!--<div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">-->
            <!--        <div class="info-box bg-blue hover-expand-effect">-->
            <!--            <div class="icon">-->
            <!--                <i class="material-icons">perm_media</i>-->
            <!--            </div>-->
            <!--            <div class="content">-->
            <!--                <div class="text">Total Events</div>-->
            <!--                <div class="number count-to" data-from="0" data-to="<?php //echo $total; ?>" data-speed="1000" data-fresh-interval="20"></div>-->
            <!--            </div>-->
            <!--        </div>-->
            <!--    </div>-->


             <?php
// include("db.php");

// $result = mysqli_query($db,"select count(1) FROM delegates");
// $row = mysqli_fetch_array($result);

// $total = $row[0];
// echo "Total rows: " . $total;
?>
          
                <!--<div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">-->
                <!--    <div class="info-box bg-light-green hover-expand-effect">-->
                <!--        <div class="icon">-->
                <!--            <i class="material-icons">forum</i>-->
                <!--        </div>-->
                <!--        <div class="content">-->
                <!--            <div class="text">Total Delegates</div>-->
                <!--            <div class="number count-to" data-from="0" data-to="<?php //echo $total; ?>" data-speed="1000" data-fresh-interval="20"></div>-->
                <!--        </div>-->
                <!--    </div>-->
                <!--</div>-->
              
           


            <?php
// include("db.php");

// $result = mysqli_query($db,"select count(1) FROM gallery");
// $row = mysqli_fetch_array($result);

// $total = $row[0];
// echo "Total rows: " . $total;
?>
          
            <!--    <div class="col-lg-3 col-md-3 col-sm-6 col-xs-12">-->
            <!--        <div class="info-box bg-orange hover-expand-effect">-->
            <!--            <div class="icon">-->
            <!--                <i class="material-icons">forum</i>-->
            <!--            </div>-->
            <!--            <div class="content">-->
            <!--                <div class="text">Total Gallery Photos</div>-->
            <!--                <div class="number count-to" data-from="0" data-to="<?php echo $total; ?>" data-speed="1000" data-fresh-interval="20"></div>-->
            <!--            </div>-->
            <!--        </div>-->
            <!--    </div>-->
              
            <!--</div>-->
             <!--#END# Widgets -->
             <!--CPU Usage -->
         
             <!--#END# CPU Usage -->
           
        </div>
    </section>

  