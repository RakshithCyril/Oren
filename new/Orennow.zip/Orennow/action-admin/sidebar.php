 <!-- #Top Bar -->
    <section>
        <!-- Left Sidebar -->
        <aside id="leftsidebar" class="sidebar" style="top: 95px;">
            <!-- User Info -->
            <div class="user-info">
                 <div class="image">
                    <img src="images/user.png" width="48" height="48" alt="User" />
                </div> 
                <div class="info-container">
                     <div class="name" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Admin</div>
                    <div class="email">Oren</div> 
                   
                </div>
            </div>
            <!-- #User Info -->
            <!-- Menu -->
            <div class="menu" style="overflow-y: hidden;">
                <ul class="list">
                   
                    
                    
                    <li>
                        <a href="javascript:void(0);" class="menu-toggle">
                            <i class="material-icons">perm_media</i>
                            <span>Blogs</span>
                        </a>
                        <ul class="ml-menu">

                            <li>
                                <a href="addblog.php">Add Blogs</a>
                            </li>
                            <li>
                                <a href="blog_info.php">View Blog</a>
                            </li>
                    <li> 
                    </ul>

                    </li>


                </ul>
            </div>
        
        </aside>
        <!-- #END# Left Sidebar -->
   
        <!-- #END# Right Sidebar -->
    </section>
